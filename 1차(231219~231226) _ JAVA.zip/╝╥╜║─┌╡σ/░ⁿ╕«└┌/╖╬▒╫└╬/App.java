package com.kb.example;

import java.util.Date;
import java.util.Objects;
import java.util.Scanner;
/**
 * 본 스크립트는 IntelliJ Community Edition 최신 버전으로 작성되었습니다.
 */
@SuppressWarnings("SpellCheckingInspection")
public class App {// 메인 프로그램이 실제 동작을 수행하는 스크립트.
	public void run() {//main()을 별도의 클래스 파일로 분리했기 때문에 실행 프로그램의 main()에 들어가는 코드는 여기에 작성
		Scanner s  = new Scanner(System.in);// 일반 입력기
		Scanner pw = new Scanner(System.in);// 비밀번호 입력기
		String login;// 로그인할 계정 ID를 입력받을 String 변수

		String adm = LoginType.ADMIN.getAcc();//    관리자 계정 형식
		String std = LoginType.STUDENT.getAcc();//  학생 계정 형식

		String pw_adm;// 관리자 계정 비밀번호 값
		String pw_std;// 학생 계정 비밀번호 값

		Admin admin = new Admin();//        관리자용 프로그램 선언
		Student student = new Student();//  학생용 프로그램 선언

		int failCnt = 0;//              로그인 실패 횟수 정수 값
		Date lastFailT = new Date();//  로그인 실패 시 활성화되는 제한 시간 값

		boolean run = true;// 실행 여부(참: 실행 중, 거짓: 종료 됨)

		while(run) {// 메인 프로그램이 실행되는 동안 사용자에게 로그인할 계정 ID와 비밀번호에 대한 입력값을 받는 인터페이스를 제공
			System.out.println("로그인할 계정을 입력하세요. (admin, student 중 입력. 종료하려면 exit을 입력)");
			System.out.print(">> ");
			login = s.nextLine();
			LineJump.simple();// 줄바꿈용. System.out.println()을 간략화한 버전.
			if(Objects.equals(login, adm)) {
				if(failCnt >= 5 && (new Date().getTime() - lastFailT.getTime()) < 300000) {//   비밀번호 횟수 초과 및 타이머 초기화 시
					long remainT = 300000 - (new Date().getTime() - lastFailT.getTime());//     로그인을 제한하는 타이머 작동(지속시간: 5분)
					System.out.println("경고: 관리자 로그인이 제한되어 있습니다. 권한이 없거나 비밀번호 횟수를 초과했습니다.");
					System.out.println("제한 해제까지: " + remainT / 1000 + "초");// 로그인 제한 동안 타이머를 시각적으로 표시
				} else {
					admLogin:
					for(int i = 1; i < 6; i++) {
						System.out.println("관리자로 로그인하려면 비밀번호를 입력하세요. (취소하려면 cancel을 입력)");
						System.out.print("비밀번호 입력>> ");
						pw_adm = pw.next();
						LineJump.simple();// 줄바꿈
						switch(pw_adm) {// 비밀번호가 일치하는지 검증(PW 기본값: 0000)
							case "cancel":// 로그인 취소
								System.out.println("로그인 과정을 취소합니다.\n");
								break admLogin;
							case "0000"://   만약 비밀번호가 일치하는 경우
								System.out.println("관리자로 로그인 합니다.\n");
								admin.run();// 관리자 계정 로그온
								break admLogin;
							default://       만약 비밀번호가 일치하지 않는 경우
								System.out.println("비밀번호가 틀렸습니다. 다시 입력해주세요. (취소하려면 cancel을 입력)");
								System.out.println("틀린 횟수: [" + i + "/5]\n");
								failCnt++;
								if (failCnt >= 5) {// 만약 비밀번호를 5번 틀린 경우
									System.out.println("오류: 비밀번호가 일치하지 않음");
									System.out.println("관리자 계정 로그인에 실패했습니다. 5분동안 관리자 로그인이 제한되었습니다.");
								}
								break;
						}
					}
				}
				if((new Date().getTime() - lastFailT.getTime()) >= 300000) failCnt = 0;// 제한시간 만료 시 비밀번호 횟수 초기화
			} else if(Objects.equals(login, std)) {
				stdLogin:
				for(;;) {
					System.out.println("학생으로 로그인하려면 비밀번호를 입력하세요. (취소하려면 cancel을 입력)");
					System.out.print("비밀번호 입력>> ");
					pw_std = pw.next();
					LineJump.simple();
					switch (pw_std) {//     비밀번호가 일치하는지 검증(PW 기본값: 8자리 수 날짜(e.g. 20240101))
						case "cancel":// 로그인 취소
							System.out.println("로그인 과정을 취소합니다.\n");
							break stdLogin;// 학생 계정 로그온
						case "20240101"://  만약 비밀번호가 일치하는 경우
							System.out.println("학생으로 로그인 합니다.\n");
							student.run();
							break stdLogin;
						default://          만약 비밀번호가 일치하지 않는 경우
							System.out.println("비밀번호가 틀렸습니다. 다시 입력해주세요. (취소하려면 cancel을 입력)");
							break;
					}
				}
			} else if(Objects.equals(login, "exit")) {// 만약 사용자가 종료를 원하는 경우
				System.out.println("프로그램을 종료합니다.\n");
				run = false;// 메인 프로그램 종료
			} else {// 만약 존재하지 않는 계정 ID를 입력했을 경우
				System.out.println("오류: 유효하지 않은 계정입니다.\n");
				continue;
			}
			LineJump.simple();
		} Main.isRunning = false;
	}

	private enum LoginType {// 계정 ID 종류
		ADMIN("admin"),//       관리자 계정
		STUDENT("student");//   학생 계정

		final String acc;

		LoginType(String logon) { this.acc = logon; }
		public String getAcc() { return acc; }
	}
}
