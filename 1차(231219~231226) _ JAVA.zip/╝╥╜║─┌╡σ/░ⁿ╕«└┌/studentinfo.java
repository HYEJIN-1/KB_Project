package com.java.project;

class studentinfo {
	String studentName;
	String studentPhone;
	String studentEmail;
	String studentSubject;
	
	public studentinfo(String studentName, String studentPhone, String studentEmail, String studentSubject) {
		this.studentName = studentName;
		this.studentPhone = studentPhone;
		this.studentEmail = studentEmail;
		this.studentSubject = studentSubject;
	}
	
	public void studentPrint() {
		System.out.printf("학생이름: %s\t학생전화번호: %s\t학생이메일: %s\t수강과정: %s\n", studentName, studentPhone, studentEmail, studentSubject);
	}

}


