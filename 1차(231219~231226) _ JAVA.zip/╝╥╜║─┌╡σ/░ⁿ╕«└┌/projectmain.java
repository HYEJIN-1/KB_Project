package com.java.project;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
/*
 * 학생 출결 관리 프로그램
 * 
 * 관리자가 학생의 정보와 출결을 관리하는 프로그램이다.
 * 
 * 이 프로그램은 학생등록과 학생 출결을 직접 입력해야합니다.
 * 전화번호와 이메일은 같은 값이 중복되서 입력이 되지 않도록 만들었습니다.
 * 
 * 학생정보에는 학생이름 전화번호 이메일 수강과목이 입력되고
 * 학생출결정보에는 학생이름 전화번호 출석 지각 조퇴 결석 휴가/병가 입력됩니다.
 * 
 * 하지만 학생등록정보의 '학생이름 전화번호'과 학생출결 정보의 '학생이름 전화번호'는 서로 독립적입니다.
 * 불편하지만 각각 따로 입력해야합니다.
 * 
 * 즉 학생정보와 학생출결정보는 연결점이 없는 독립적인 배열입니다.
 * 
 * 다행히 학생등록정보와 학생출결정보의 '전화번호'의 정보가 같다면 같은 학생으로 인식해 두 배열에서 함께 삭제됩니다.  
 * 
 * 주로 List, ArrayList, ListIterator, Scanner 문법을 사용했습니다.
 * 
 */
public class projectmain {
	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		List<studentinfo> studentInfo = new ArrayList<>();
		ListIterator<studentinfo> student;
		
		List<management> manageMent = new ArrayList<>();
		ListIterator<management> manage;

		int a = 0;
		
		while(a != 7) {                      // 프로그램 실행!!!!  메인 메뉴에서 종료를 제외한 6가지 작업을 수행할수있다.
			System.out.println("===================================================================================================");
			System.out.println("||| [1:학생등록] [2:학생정보수정및확인] [3:학생출결조회] [4:학생출결 입력 및 수정] [5:내보내기] [6:가져오기] [7:종료] |||");
			System.out.println("===================================================================================================");
			
			System.out.println();
			System.out.print("메뉴선택>> ");   // 메뉴선택!!!!
			a = s.nextInt();
			s.nextLine();
			
			while(a == 1) {                  // 학생등록 메뉴 선택
				student = studentInfo.listIterator();
				studentinfo stp;
				
				System.out.println();
				System.out.println("===================================================================================================");
				System.out.println("<학생등록>");
				System.out.println();
				
				System.out.print("학생 이름: ");
				String studentName = s.nextLine();   // 학생 이름 입력
				System.out.println();
				
				
				System.out.print("학생 전화번호: ");    // 학생 전화번호 입력
				String phone = s.nextLine();
				System.out.println();
				
				while(student.hasNext()) {
					stp = student.next();
					while(stp.studentPhone.equals(phone)){
						System.out.println("전화번호가 중복됩니다. 다시입력하세요.");   // (while)이미 입력된 전화번호는 입력이 안되도록 설계
						System.out.print(">");
						phone = s.nextLine();
						System.out.println();
					}
				}
				
				String studentPhone = phone;
				
				System.out.print("학생 이메일: ");      // 학생 이메일 입력
				String studentEmail = s.nextLine();
				System.out.println();
				
				System.out.print("수강과정: ");         // 학생 수강과정 입력
				String studentSubject = s.nextLine();
				System.out.println();
				
				studentInfo.add(new studentinfo(studentName, studentPhone, studentEmail, studentSubject));   // 입력된 정보를 배열에 저장
				
				System.out.println("계속 등록(1)\t등록 종료(0) ");   // (while)추가로 학생정보를 입력할수있다. 
				System.out.print(">");
				int b = s.nextInt();
				s.nextLine();
				if(b == 0) {
					break;  // 메인메뉴로 돌아가기
				}
			}
			
			while(a == 2) {      // 2번 학생정보수정및확인 메뉴 선택
				System.out.println();
				System.out.println("===================================================================================================");
				System.out.println("<학생정보수정및확인>");  //학생정보수정및확인에서는 나가기를 제외한 3가지의 작업을 할수있다.
				System.out.println("1. 학생_정보확인 2. 학생_정보수정 3. 학생_퇴원관리 4. 나가기");
				System.out.print(">");
				int c = s.nextInt();
				s.nextLine();
				
				if(c == 1) {      // 1번 학생_정보확인 선택
					System.out.println();
					System.out.println("<학생_정보확인>");
					System.out.println("===================================================================================================");
					for(studentinfo stp : studentInfo) {   // 저장된 학생 정보 배렬을 불러와 출력
						stp.studentPrint();
					}
					System.out.println("===================================================================================================");
				}  //  (if) '학생정보수정및확인'메뉴로 돌아가기
				System.out.println();
				
				while(c == 2) {  // 2번 학생_정보수정 선택
					student = studentInfo.listIterator();
					studentinfo stp;
					
					System.out.println();
					System.out.println("<학생_정보수정>");
					System.out.println("===================================================================================================");
					for(studentinfo st : studentInfo) {    // 학생 조회에 편하도록 학생 정보 배열을 출력함
						st.studentPrint();
					}
					System.out.println("===================================================================================================");
					
					System.out.print("수정할 학생 전화번호: ");  // 학생 전화번호로 정보를 조회하는 이유는 전화번호가 고유번호이기 때문에 동명이인이라도 분리하여 선택할수있다.
					String phone1 = s.nextLine();
					System.out.println();
					
					while(student.hasNext()) {
						stp = student.next();
						if(stp.studentPhone.equals(phone1)) {
							
							System.out.print("새로운 학생이름: ");
							String Name = s.nextLine();    // 수정된 학생 이름 입력
							System.out.println();
							
							System.out.print("새로운 학생 전화번호: ");
							String Phone = s.nextLine();   // 수정된 학생 전화번호 입력
							System.out.println();
							
							System.out.print("새로운 학생 이메일: ");
							String Email = s.nextLine();   // 수정된 학생 이메일 입력
							System.out.println();
							
							System.out.print("새로운 학생 수강과정: ");
							String Subject = s.nextLine(); // 수정된 학생 수강과정 입력
							System.out.println();
							
							stp.studentName = Name;
							stp.studentPhone = Phone;
							stp.studentEmail = Email;
							stp.studentSubject = Subject;
							
							student.set(stp);     // 수정된 입력된 정보를 배열에 저장
							
							System.out.printf("수정된 학생 정보\n학생 이름: %s 학생 전화번호: %s 학생 이메일%s 수강과정: %s\n", Name, Phone, Email, Subject);  // 수정된 정보를 출력
						}
						
					}
					break;   //   '학생정보수정및확인'메뉴로 돌아가기
				}
				if(c == 3) {  // 3번 학생_퇴원관리 선택
					manage = manageMent.listIterator();
					management ma;
					student = studentInfo.listIterator();
					studentinfo stp;
				
					System.out.println();
					System.out.println("<학생_퇴원관리>");
					System.out.println("===================================================================================================");
					for(management man : manageMent) {
						man.managePrint();
					}
					System.out.println("===================================================================================================");
				
					System.out.print("퇴원할 학생 전화번호: ");
					String phone = s.nextLine();                            // 전화번호 입력
					System.out.println();                // 학생 전화번호로 정보를 조회하는 이유는 전화번호가 고유번호이기 때문에 동명이인이라도 분리하여 선택할수있다.
				
					while(manage.hasNext()) {                               // 학생 출결 정보에 학생 전화번호를 저장했고 전화번호의 값과 같은 배열 삭제  
						ma = manage.next();
						if(ma.managePhone.equals(phone)) {
							manage.remove();
						}
					}
					while(student.hasNext()) {                              // 학생 정보에 학생 전화번호를 저장했고 전화번호의 값과 같은 배열 삭제 
						stp = student.next();
						if(stp.studentPhone.equals(phone)) {            // 학생 출결 정보 배열과 학생 정보 배열은 독립되어있다. 하지만 전화번호는 동일하하다.
							student.remove();                           // 따라서 전화번호 정보로 두배열에서 삭제가 가능하다.
							System.out.println(stp.studentName + "퇴원");
						}
					}
					
				}  //  (if) '학생정보수정및확인'메뉴로 돌아가기
				if(c == 4) {
					break;     //  메인메뉴로 돌아가기
				}
				
			}
			
			if(a == 3) {
				System.out.println();
				System.out.println("<학생_출결조회>");
				System.out.println("===================================================================================================");
				for(management man : manageMent) {
					man.managePrint();
				}
				System.out.println("===================================================================================================");
				System.out.println();
			}
			
			while(a == 4) {
				
				System.out.println();
				System.out.println("<학생_출결입력 및 수정>");
				System.out.println("===================================================================================================");
				System.out.println("1. 학생_출결입력 2. 학생_출결수정 3. 나가기");
				System.out.print(">");
				int e = s.nextInt();
				s.nextLine();
				
				while(e == 1) {     // 1. 학생_출결입력메뉴 선택
					student = studentInfo.listIterator();
					studentinfo stp;
					
					System.out.println();
					System.out.println("<학생_정보확인>");
					System.out.println("===================================================================================================");
					for(studentinfo st : studentInfo) {   // 저장된 학생 정보 배렬을 불러와 출력
						st.studentPrint();
					}
					System.out.println("===================================================================================================");
					
					System.out.println();
					System.out.println("<학생_출결 입력>");
					System.out.println("===================================================================================================");
					
					System.out.print("출결 입력할 학생 전화번호: ");
					String phone = s.nextLine();     // 학생 전화번호로 정보를 조회하는 이유는 전화번호가 고유번호이기 때문에 동명이인이라도 분리하여 선택할수있다.
					System.out.println();
					
					while(student.hasNext()) {
						stp = student.next();
						if(stp.studentPhone.equals(phone)) {
							String namename = stp.studentName;
							System.out.print("학생 이름: " + stp.studentName);  // 학생정보관리 배열에서 이름을 가져다 사용
							System.out.println();
							System.out.println();
							
							System.out.print("학생 전화번호 확인: ");    // 전화번호 확인을 위해서 한번더 전화번호 입력을 요구함
							String Phone = s.nextLine();
							System.out.println();
							
							manage = manageMent.listIterator();
							management ma;
							
							while(manage.hasNext()) {
								ma = manage.next();
								while(ma.managePhone.equals(Phone)){
									System.out.println("전화번호가 중복됩니다. 다시입력하세요.");    // (while)이미 입력된 전화번호는 입력이 안되도록 설계
									System.out.print(">");
									Phone = s.nextLine();
									System.out.println();
								}
							}
							String managePhone = Phone;
							
							System.out.print("출석: ");         // 학생 출석일수
							String attendance = s.nextLine();
							System.out.println();
							
							System.out.print("지각: ");         // 학생 지각횟수
							String tardiness = s.nextLine();
							System.out.println();
							
							System.out.print("조퇴: ");         // 학생 조퇴횟수
							String earlyLeave = s.nextLine();
							System.out.println();
							
							System.out.print("결석: ");         // 학생 결석횟수
							String absent = s.nextLine();
							System.out.println();
							
							System.out.print("휴가/병가: ");         // 학생 휴가/병가횟수
							String vacationSick = s.nextLine();
							System.out.println();
							
							manageMent.add(new management(namename, managePhone, attendance, tardiness, earlyLeave, absent, vacationSick));   // 입력된 정보를 배열에 저장	
						}
					}
					
					break;   //  학생_출결입력 및 수정메뉴로 돌아가기
				}
				
				if(e == 2) {    // 2. '학생_출결수정' 메뉴 선택
					manage = manageMent.listIterator();
					management ma;
					
					System.out.println("===================================================================================================");
					for(management man : manageMent) {   //  학생 정보 출력
						man.managePrint();
					}
					System.out.println("===================================================================================================");
					
					System.out.println();
					System.out.println("<학생_출결 수정>");
					System.out.println("===================================================================================================");
					                                       // 학생 전화번호로 정보를 조회하는 이유는 전화번호가 고유번호이기 때문에 동명이인이라도 분리하여 선택할수있다.
					System.out.print("수정할 학생 전화번호: ");
					String phone = s.nextLine();
					System.out.println();
					
					while(manage.hasNext()) {
						ma = manage.next();
						if(ma.managePhone.equals(phone)) {
							
							String r1 = ma.namename;
							System.out.print("학생 이름: " + ma.namename);   // 이름은 '학생_출결 수정'에서 변경할수 있는 값이 아니다.
							System.out.println();
							System.out.println();
							
							String r2 = ma.managePhone;
							System.out.print("학생 전화번호: " + ma.managePhone);   // 전화번호는 '학생_출결 수정'에서 변경할수 있는 값이 아니다.
							System.out.println();
							System.out.println();
							
							System.out.print("출석: ");
							String r3 = s.nextLine();
							System.out.println();
							
							System.out.print("지각: ");
							String r4 = s.nextLine();
							System.out.println();
							
							System.out.print("조퇴: ");
							String r5 = s.nextLine();
							System.out.println();

							System.out.print("결석: ");
							String r6 = s.nextLine();
							System.out.println();
							
							System.out.print("휴가/병가: ");
							String r7 = s.nextLine();
							System.out.println();


							ma.namename = r1;
							ma.managePhone = r2;
							ma.attendance = r3; 
							ma.tardiness = r4;
							ma.earlyLeave = r5;
							ma.absent = r6;
							ma.vacationSick = r7;
							
							manage.set(ma);     //  배열에 수정된 내용 저장
							
							System.out.printf("수정된 학생 출결정보\n학생 이름: %s 학생 전화번호: %s 출석일수: %s 지각: %s 조퇴: %s 결석: %s 휴가/병가: %s\n", r1, r2, r3, r4, r5, r6, r7);
							//  수정된 내용 확인
						}
						
					}	
				
				}
				
				if(e == 3) {
					a = 0;
				}
				
			}

		}
		
		System.out.println();
		System.out.println();
		System.out.println("로그아웃 중입니다...");
	}
}
