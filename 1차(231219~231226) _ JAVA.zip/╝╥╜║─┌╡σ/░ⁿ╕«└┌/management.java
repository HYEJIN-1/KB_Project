package com.java.project;

class management {
		String namename;
		String managePhone;
		String attendance;
		String tardiness;
		String earlyLeave;
		String absent;
		String vacationSick;
		
		public management(String namename, String managePhone, String attendance, String tardiness, String earlyLeave, String absent, String vacationSick) {
			this.namename = namename;
			this.managePhone = managePhone;
			this.attendance = attendance;
			this.tardiness = tardiness;
			this.earlyLeave = earlyLeave;
			this.absent = absent;
			this.vacationSick = vacationSick;
		}
		
		public void managePrint() {
			System.out.printf("학생이름: %s 학생전화번호: %s 출석: %s 지각: %s 조퇴: %s 결석: %s 병가/휴가: %s\n", namename, managePhone,attendance, tardiness, earlyLeave, absent, vacationSick);
		}	
}
