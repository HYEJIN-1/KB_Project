package com.java.project1;

import java.time.Duration;
import java.time.LocalTime;

public class Attendancer {
		 
		LocalTime startTime1;	// 출석 시간
		LocalTime endTime1;	// 퇴실 시간
		LocalTime standardTime1 = LocalTime.of(9, 0);	// 입실 기준 시간
		LocalTime standardTime2 = LocalTime.of(16, 0);	// 퇴실 기준 시간
		LocalTime standardTime3 = LocalTime.of(12, 30);	// 출석과 지각/조퇴 기준 시간
		Duration between1; 	
		long a; 	
		int b; 
		static int c = 20; // 출석 횟수(임의 초기값 적용ver.)
		static int d = 1; // 지각 횟수(임의 초기값 적용ver.)
		static int e = 1; // 조퇴 횟수(임의 초기값 적용ver.)
		static int f = 3; // 결석 횟수(임의 초기값 적용ver.)
		static int g = 0; // 휴가 횟수(임의 초기값 적용ver.)
		public Attendancer(LocalTime startTime1, LocalTime endTime1) {
			this.startTime1=startTime1;
			this.endTime1=endTime1;
			this.between1 = Duration.between(startTime1, endTime1); // Duration형태 출석시간과 퇴실시간 차이
			a = between1.getSeconds(); // 출석시간과 퇴실시간의 차이를 초로 환산(long 형)
			b = (int)a/60; // 출석시간과 퇴실시간의 차이를 분으로 환산(int 형)
		}
		public void showCheck() { // 출석/지각/조퇴/결석을 구분하기 위한 조건문 및 해당조건에 맞는 일수 증가 하는 메소드
			if(startTime1.isBefore(standardTime1) && (endTime1.isAfter(standardTime2) || endTime1.equals(standardTime2))) {
				
				System.out.println("출석체크 완료!"); 
				Attendancer.checkIn(); // '9시전 입실 & 16시부터 퇴실'조건 만족시 출석으로 인정
			} else if((startTime1.isAfter(standardTime1) || startTime1.equals(standardTime1)) && (startTime1.isBefore(standardTime3) || startTime1.equals(standardTime3)) && b >= 210)  {
				
				System.out.println("지각입니다.");
				Attendancer.lateIn(); // '9시이후 입실 & 16시부터 퇴실 & 수업시간 절반이상 수강(3시간 30분)'조건 만족시 지각으로 인정
			} else if(startTime1.isBefore(standardTime1) && endTime1.isBefore(standardTime2) && b >= 210) {
				
				System.out.println("조퇴입니다.");
				Attendancer.earlyIn(); // '9시전 입실 & 16시전 퇴실 & 수업시간 절반이상 수강(3시간 30분)'조건 만족시 조퇴로 인정
			} else {
				System.out.println("결석입니다.");
				Attendancer.outIn(); // 그 외의 사항은 결석으로 처리
			}
				
		}
		public static int checkIn() { // 출석 횟수 증가 메소드
			return c++;
		}
		public static int lateIn() { // 지각 횟수 증가 메소드
			return d++;
		}
		public static int earlyIn() { // 조퇴 횟수 증가 메소드
			return e++;
		}
		public static int outIn() { // 결석 횟수 증가 메소드
			return f++;
		}
		public static int vacationIn() { // 휴가 횟수 증가 메소드
			return g++;
		}
		public static void showAll() { // 출결 조회 메소드
			System.out.println("출석: " + c + " 결석: " + f + " 조퇴/지각: " + (d+e) + " 남은 결석 횟수: " + (20-f));
		}
		public static int showAll2() { // 휴가 처리시 출결증감 메소드
			return f-- & c++ & g++; 
		}
		public static void showAll3() { // 휴가 처리를 반영한 출결 조회 메소드
			System.out.println("출석: " + c + " 결석: " + f + " 조퇴/지각: " + (d+e) + " 휴가 사용일: " + g);
		}
		public static void endGame() { // 프로그램 종료 메소드
			System.out.println("종료되었습니다.");
		}
		
			
		
	}