package com.java.project1;

import java.util.Scanner;
import java.time.Duration;
import java.time.LocalTime;

public class Studentuse1 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		boolean loop = true;
		LocalTime c = LocalTime.of(0,0);
		LocalTime e = LocalTime.of(12,0);
		while(loop) { // 프로그램 반복 동작 장치
			System.out.println("┌──────────────────────────────┐");
			System.out.println("│1.출결  2.출결조회  3.휴가관리 4.종료 │");
			System.out.println("└──────────────────────────────┘");
			System.out.print("번호를 입력하세요> ");
			int n = scan.nextInt();
			if(n==1) { // 1번 출결
				System.out.println("┌──────────────┐");
				System.out.println("│1.출석  2.퇴실   │");
				System.out.println("└──────────────┘");
				System.out.print("번호를 입력하세요> ");
				int m = scan.nextInt();
				scan.nextLine();
				if(m==1) { // 1-1 출석 입력
					System.out.print("입실 시간을 입력하세요> ");
					String b = scan.nextLine();
					c =LocalTime.parse(b);
					System.out.println("출석시간 : " + c);
				} else if(m==2) { // 1-2 퇴실 입력
					System.out.print("퇴실 시간을 입력하세요> ");
					String d = scan.nextLine();
					e =LocalTime.parse(d);
					System.out.println("퇴실시간 : " + e);
					Attendancer normal = new Attendancer(c,e);
					normal.showCheck();
				}
			} else if(n==2) { // 2번 출결조회
				Attendancer.showAll();
			} else if(n==3) { // 3번 휴가관리
				System.out.println("┌───────────────┐");
				System.out.println("│1.휴가등록  2.조회 │");
				System.out.println("└───────────────┘");
				System.out.print("번호를 입력하세요> ");
				int o = scan.nextInt();
				scan.nextLine();
				if(o==1) { // 3-1 휴가등록
					System.out.print("휴가를 등록하시겠습니까? > ");
					String va = scan.nextLine();
					System.out.println("휴가 관련 서류를 제출하였습니다.");
					Attendancer.showAll2();
				} else if(o==2) { // 3-2 휴가포함 조회
					Attendancer.showAll3();
				}
			} else if(n==4) { // 종료
				loop = false;
				Attendancer.endGame();
			}
		}
		

	}

}